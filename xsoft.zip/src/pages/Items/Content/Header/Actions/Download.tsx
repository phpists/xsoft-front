import { BiDownload } from "react-icons/bi";

export const Download = () => (
  <button>
    <BiDownload size={20} />
  </button>
);

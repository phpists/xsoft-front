import styled from "styled-components";
import { Header } from "./Header/Header";
import { ProductsTable } from "./ProductsTable/ProductsTable";
import { Categories } from "../Categories/Categories";

interface Props {
  selected: number[];
  onSelect: (id: number) => void;
  onSelectAll: () => void;
}

export const Content = ({ selected, onSelect, onSelectAll }: Props) => (
  <StyledContent>
    <Header />
    <div className="flex w-full gap-2">
      <Categories />
      <ProductsTable
        selected={selected}
        onSelect={onSelect}
        onSelectAll={onSelectAll}
      />
    </div>
  </StyledContent>
);

const StyledContent = styled.div`
  padding: 10px 14px 14px;
  position: relative;
`;

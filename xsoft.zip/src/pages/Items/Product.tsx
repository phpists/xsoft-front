import { Header } from "../../components/Header/Header";
import { Content } from "./Content/Content";
import { Items } from "./Items";

export const Product = () => (
  <div>
    <Header />
    <Items />
  </div>
);

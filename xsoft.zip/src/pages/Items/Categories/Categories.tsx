import { useState } from "react";
import { CategoryCard } from "../../../components/CategoryCard/CategoryCard";
import { Title } from "../Title";
import { BiIdCard } from "react-icons/bi";
import { CategoryModal } from "../../../components/CategoryModal/CategoryModal";
import { Button } from "../../../components/Button";
import styled from "styled-components";

export const Categories = () => {
  const [modal, setModal] = useState(false);

  return (
    <StyledCategories>
      {" "}
      {modal && <CategoryModal onClose={() => setModal(false)} />}
      <Title title="Категорії товару" />
      <CategoryCard
        title="Категорія 1"
        Icon={<BiIdCard size={20} />}
        className="mb-3.5"
        editable
        onClick={() => setModal(true)}
      />
      <CategoryCard
        title="Категорія 1"
        Icon={<BiIdCard size={20} />}
        className="mb-3.5"
        editable
        onClick={() => setModal(true)}
      />
      <CategoryCard
        title="Категорія 1"
        Icon={<BiIdCard size={20} />}
        className="mb-3.5"
        editable
        onClick={() => setModal(true)}
      />
      <CategoryCard
        title="Категорія 1"
        Icon={<BiIdCard size={20} />}
        className="mb-3.5"
        editable
        onClick={() => setModal(true)}
      />
      <CategoryCard
        title="Категорія 1"
        Icon={<BiIdCard size={20} />}
        className="mb-3.5"
        editable
        onClick={() => setModal(true)}
      />
      <Button
        title="Додати категорію"
        type="dark"
        onClick={() => setModal(true)}
      />
    </StyledCategories>
  );
};

const StyledCategories = styled.div`
  box-shadow: 0px 6px 14px 0px #1e1e1e1a;
  border-radius: 8px;
  background: #ffffff;
  width: 300px;
  padding: 20px 8px 40px;
  flex-shrink: 0;
`;

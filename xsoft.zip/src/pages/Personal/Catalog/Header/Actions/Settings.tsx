import { BiCog } from "react-icons/bi";

export const Settings = () => (
  <button>
    <BiCog size={20} />
  </button>
);

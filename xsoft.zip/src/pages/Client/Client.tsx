import { Header } from "../../components/Header/Header";
import { Content } from "./Content/Content";

export const Client = () => {
  return (
    <div>
      <Header />
      <Content />
    </div>
  );
};

import { Header } from "../../components/Header/Header";
import { Content } from "./Content/Content";

export const Storage = () => (
  <div>
    <Header />
    <Content />
  </div>
);

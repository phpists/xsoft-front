import { BiCog } from "react-icons/bi";

export const Setting = () => (
  <button>
    <BiCog size={24} />
  </button>
);

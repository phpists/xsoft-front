import { BiDotsHorizontalRounded } from "react-icons/bi";

export const Actions = () => (
  <button>
    <BiDotsHorizontalRounded size={24} />
  </button>
);

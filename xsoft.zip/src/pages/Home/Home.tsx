import { Header } from "../../components/Header/Header";
import { Content } from "./Content/Content";

export const Home = () => (
  <div>
    <Header />
    <Content />
  </div>
);

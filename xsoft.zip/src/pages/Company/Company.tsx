import { Header } from "../../components/Header/Header";
import { Content } from "./Content/Content";

export const Company = () => (
  <div>
    <Header />
    <Content />
  </div>
);

import { Header } from "../../components/Header/Header";
import { Content } from "./Content/Content";

export const Brand = () => (
  <div>
    <Header />
    <Content />
  </div>
);

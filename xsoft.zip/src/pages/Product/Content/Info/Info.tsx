import styled from "styled-components";
import { Empty } from "./Empty";
import { Product } from "./Product";
import { Media } from "../../../../components/Media/Media";
import { Location } from "../../../../components/Location";
import { IProduct } from "../../../../types/products";

interface Props {
  title: string;
  color: string;
  category?: string;
}

export const Info = ({ title, color, category }: Props) => {
  return (
    <StyledInfo>
      {/* <Empty /> */}
      {title?.length === 0 ? <Empty /> : null}
      {title?.length > 0 ? (
        <Product title={title} color={color} category={category} />
      ) : null}
      {/* <Location location="Львів, Дрогобич" className="mt-2.5 mb-6" /> */}
      {/* <Media /> */}
    </StyledInfo>
  );
};

const StyledInfo = styled.div`
  border-right: 1px solid #dbdbdb;
  padding: 14px;
`;

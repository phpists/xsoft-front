import styled from "styled-components";
import { Header } from "./Header/Header";
import { Info } from "./Info/Info";
import { Tabs } from "../../../components/Tabs/Tabs";
import { BiSolidCartAlt } from "react-icons/bi";
import { useState } from "react";
import { Information } from "./Information/Information";
import {
  useGetProductInfoQuery,
  useLazyAddProductQuery,
} from "../../../store/products/products.api";
import { IProduct, IProductItem } from "../../../types/products";
import { showMessage } from "../../../helpers";

const TABS = [{ title: "Інформація", Icon: BiSolidCartAlt }];

export const INIT_PRODUCT_ITEM: IProductItem = {
  tax_id: 1,
  cost_price: 0,
  retail_price: 0,
};

const INIT_VALUE = {
  brand_id: undefined,
  category_id: undefined,
  article: "",
  title: "",
  description: "",
  product_measure_id: undefined,
  color: "#2EB062",
  balance: 0,
  materials_used_quantity: 0,
  materials_used_measure_id: undefined,
  items: [INIT_PRODUCT_ITEM],
  test: [],
};

export const Content = () => {
  const { data: productInfo } = useGetProductInfoQuery({});
  const [data, setData] = useState<IProduct>(INIT_VALUE);
  const [activeTab, setActiveTab] = useState(0);
  const [addProduct] = useLazyAddProductQuery();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const handleChangeTab = (tab: number) => setActiveTab(tab);
  const handleChangeField = (
    field: string,
    value: string | boolean | number | IProductItem[] | string[] | number[]
  ) => {
    setData({ ...data, [field]: value });
    setErrors(errors.filter((e) => e !== field));
  };

  const handleCheckFields = () => {
    const fieldsErr: string[] = [];

    !data.brand_id && fieldsErr.push("brand_id");
    !data.category_id && fieldsErr.push("category_id");
    !data.product_measure_id && fieldsErr.push("product_measure_id");

    setErrors(fieldsErr);
    if (fieldsErr.length > 0) {
      showMessage("error", "Заповніть обов'язкові поля");
    }
    return fieldsErr.length === 0;
  };

  const handleSave = () => {
    if (handleCheckFields()) {
      addProduct(data).then(async (resp: any) => {
        setLoading(false);
        if (!resp.isError) {
          //   if (data?.media?.length > 0) {
          //     const clientId = resp?.data?.response?.user?.id;
          //     await handleSaveMedia(clientId);
          //     handleSuccesCreate();
          //   } else {
          //     handleSuccesCreate();
          //   }
        } else {
          showMessage("error", resp?.error.data.message);
        }
      });
    }
  };

  return (
    <StyledContent>
      <Header />
      <div className="main-wrapper">
        <Info
          title={data.title}
          category={
            productInfo?.categories.find((c) => c.id === data.category_id)
              ?.title
          }
          color={data.color}
        />
        <div>
          <div className="py-3.5 px-4 border-b-[1px] border-[#DBDBDB]">
            <div className="w-[196px]">
              <Tabs tabs={TABS} active={activeTab} onChange={handleChangeTab} />
            </div>
          </div>
          <div className="content-wrapper no-scrollbar">
            <Information
              data={data}
              onChange={handleChangeField}
              productInfo={productInfo}
              onSave={handleSave}
              errors={errors}
            />
          </div>
        </div>
      </div>
    </StyledContent>
  );
};

const StyledContent = styled.div`
  padding: 12px 14px 14px;
  .main-wrapper {
    display: grid;
    grid-template-columns: 320px 1fr;
    border-radius: 16px;
    background: #fff;
    height: calc(100vh - 123px);
    overflow: hidden;
  }
  .content-wrapper {
    height: calc(100vh - 184px);
    background: #efefef;
    overflow: auto;
  }
`;

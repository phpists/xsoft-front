import { Button } from "../../../../../components/Button";
import { IProduct, IProductItem } from "../../../../../types/products";
import { Color } from "./Color";
import { Tags } from "./Tags";

interface Props {
  data: IProduct;
  onChange: (
    field: string,
    value: string | boolean | number | IProductItem[]
  ) => void;
  onSave: () => void;
}

export const Header = ({ data, onChange, onSave }: Props) => (
  <div className="flex items-center justify-between gap-3.5">
    <div className="flex items-center justify-between gap-2 py-[9.5px] px-3.5 bg-[#EFEFEF] rounded-[100px] w-full">
      <Color
        value={data.color}
        onChange={(val: string) => onChange("color", val)}
      />
      {/* <Tags
        value={data.tags}
        onChange={(val: string[]) => onChange("tags", val)}
      /> */}
    </div>
    <Button title="Зберегти зміни" className="!w-[155px]" onClick={onSave} />
  </div>
);

import styled from "styled-components";
import { Header } from "./Header/Header";
import { MainInfo } from "./MainInfo/MainInfo";
import { Divider } from "../Divider";
import { Category } from "./Category/Category";
import { Selling } from "./Selling/Selling";
import { Materials } from "./Materials";
import { Availability } from "./Availability";
import { Files } from "../../../../components/Files/Files";
import {
  IProduct,
  IProductInfo,
  IProductItem,
} from "../../../../types/products";

interface Props {
  data: IProduct;
  onChange: (
    field: string,
    value: string | boolean | number | IProductItem[] | string[] | number[]
  ) => void;
  productInfo?: IProductInfo;
  onSave: () => void;
  errors: string[];
}

export const Information = ({
  data,
  onChange,
  productInfo,
  onSave,
  errors,
}: Props) => (
  <StyledInformation>
    <Header data={data} onChange={onChange} onSave={onSave} />
    <MainInfo
      data={data}
      onChange={onChange}
      productInfo={productInfo}
      errors={errors}
    />
    <Divider />
    <Category
      data={data}
      onChange={onChange}
      productInfo={productInfo}
      errors={errors}
    />
    <Divider />
    <Selling
      data={data}
      onChange={onChange}
      productInfo={productInfo}
      errors={errors}
    />
    <Divider />
    {/* <Materials data={data} onChange={onChange} productInfo={productInfo} />
    <Divider /> */}
    <Availability
      data={data}
      onChange={onChange}
      productInfo={productInfo}
      errors={errors}
    />
    <Divider />
    <Files />
  </StyledInformation>
);

const StyledInformation = styled.div`
  background: #fff;
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 34px;
`;

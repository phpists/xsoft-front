import { Header } from "../../components/Header/Header";
import { Content } from "./Content/Content";

export const Product = () => (
  <div>
    <Header />
    <Content />
  </div>
);

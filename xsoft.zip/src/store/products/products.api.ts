import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { baseUrl, headers } from "../../api";
import { IProductInfo, IProductInfoResponse } from "../../types/products";

export const products = createApi({
  reducerPath: "products/api",
  baseQuery: fetchBaseQuery({ baseUrl }),
  endpoints: (build) => ({
    addProduct: build.query({
      query: (data) => ({
        url: "/product/add-product",
        method: "POST",
        body: data,
        headers: headers(),
      }),
    }),
    editProduct: build.query({
      query: (data) => ({
        url: "/product/update-product",
        method: "POST",
        body: data,
        headers: headers(),
      }),
    }),
    getProductInfo: build.query({
      query: () => ({
        url: "/product/get-product-info",
        method: "GET",
        headers: headers(),
      }),
      transformResponse: (resp: IProductInfoResponse): IProductInfo => {
        return resp?.response;
      },
    }),
    getProducts: build.query({
      query: ({ perPage = 30, page = 1, sortBy, q, sortDesc }) => ({
        url: "/product/get-products",
        method: "GET",
        params: { perPage, page, sortBy, q, sortDesc },
        headers: headers(),
      }),
      //   transformResponse: (resp: ClientsResponse): ClientsResponseData => {
      //     return resp.response;
      //   },
    }),
  }),
});

export const {
  useLazyAddProductQuery,
  useLazyEditProductQuery,
  useGetProductInfoQuery,
  useLazyGetProductsQuery,
} = products;

export interface IMedia {
  id: number;
  type_id: number;
  parent_id: number;
  file: string;
}

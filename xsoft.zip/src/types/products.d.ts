export type IProductInfoResponse = {
  code: number;
  response: IProductInfo;
};

export type IProductInfo = {
  brands: Array<{
    id: number;
    title: string;
    created_at: string;
    updated_at: string;
  }>;
  categories: Array<{
    id: number;
    title: string;
    created_at: string;
    updated_at: string;
  }>;
  measurements: Array<{
    id: number;
    title: string;
    created_at: string;
    updated_at: string;
  }>;
  taxes: Array<{
    id: number;
    title: string;
    created_at: string;
    updated_at: string;
  }>;
  warehouses: Array<{
    id: number;
    title: string;
    created_at: string;
    updated_at: string;
  }>;
};

export interface IProduct {
  brand_id?: number | undefined;
  category_id?: number | undefined;
  article: string;
  title: string;
  description: string;
  product_measure_id?: number | undefined;
  color: string;
  balance: number;
  materials_used_quantity: number;
  materials_used_measure_id: number | undefined;
  items: IProductItem[];
  test: string[] | number[];
}

export interface IProductItem {
  tax_id: number;
  cost_price: number;
  retail_price: number;
}

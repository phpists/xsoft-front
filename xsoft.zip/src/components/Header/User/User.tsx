import styled from "styled-components";
import { Avatar } from "./Avatar";
import { Dropdown } from "./Dropdown";
import { useAppSelect } from "../../../hooks/redux";

export const User = () => {
  const { user } = useAppSelect((state) => state.auth);

  console.log(user?.first_name, user?.last_name);
  return (
    <StyledUser>
      <Avatar
        firstName={user?.first_name ?? ""}
        lastName={user?.last_name ?? ""}
      />
      <Dropdown />
    </StyledUser>
  );
};

const StyledUser = styled.button`
  position: relative;
  .dropdown {
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s;
  }
  &:focus,
  &.open {
    .dropdown {
      opacity: 1;
      visibility: visible;
    }
  }
`;
